# mvyleteljr.github.io

Dead-simple static personal site. No build step, no dependencies, no JS. Plain HTML + one CSS file. Deploys as-is on GitHub Pages.

## Files
- `index.html` — homepage (photo + short bio + three links).
- `writing.html` — list of writing, grouped by category.
- `photos.html` — photo archive, grouped by category, as a grid.
- `links.html` — free-form curated links, grouped by category.
- `style.css` — all styling. Shared by every page.
- `avatar.jpg` — homepage photo. `img/` — photos.

## How to edit (this is the whole system)
- **Add a piece of writing:** add one `<li>` to `writing.html` under the right `<div class="cat">`. Format: `<li><span class="date">YYYY-MM-DD</span><a href="URL">Title</a></li>`. To add a category, copy a `<div class="cat">…</div>` + `<ul class="list">…</ul>` block.
- **Add a photo:** drop the file in `img/`, add `<a href="img/NAME.jpg"><img src="img/NAME.jpg" alt=""></a>` to `photos.html` under a category.
- **Add a link:** add one `<li>` to `links.html`. Categories are just `<div class="cat">` headers — make up new ones at will.
- **Change the bio:** edit the `<p>` tags in `index.html`.

Categories are freeform: a category exists if there's a `cat` header above a list. No config, no data files. Edit HTML directly.

## Constraints (keep it this way)
- No frameworks, no web fonts, no bundler, no JS. One CSS file.
- Everything must work as static files opened directly or served by GitHub Pages.
- Keep the single centered column. Don't add heroes, animations, or decoration.
